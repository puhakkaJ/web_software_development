# Project 1: Shared shopping list

## Description
The shared shopping list application allows you to add new shopping lists and add items to the shopping list. When the shopping list is no more needed, you can deactivate the list. List item can be overlined (marked as collected) with a button to keep track of the item needed. The main page also shows the statistic of the shopping list in the application.

## Running the application
Navigate to the root folder (where docker-compose file is) and run `docker-compose up`. Navigate to http://localhost:7777 with your bowser.

## Deployment (Heroku)
https://shopping-list-application-wsd.herokuapp.com




